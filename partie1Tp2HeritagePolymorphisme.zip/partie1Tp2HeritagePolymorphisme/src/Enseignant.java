public interface Enseignant {

    double getChargeHoraire();
    double getVacations();
}
