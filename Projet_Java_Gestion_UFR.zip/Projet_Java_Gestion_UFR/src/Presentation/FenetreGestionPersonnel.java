package Presentation;

import javax.swing.*;

public class FenetreGestionPersonnel extends JFrame {
}
